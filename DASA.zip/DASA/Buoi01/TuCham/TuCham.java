import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Công cụ tự chấm bài tập môn DASA230179.
 *
 * Cách dùng: đặt TuCham.java, thư mục tests và file bài làm (ví dụ B01_TongChuSo.java)
 * vào cùng một thư mục, mở cửa sổ dòng lệnh tại thư mục đó và gõ
 *     java TuCham.java B01_TongChuSo
 * Yêu cầu JDK 17 trở lên. File bài làm không được khai báo package.
 */
public class TuCham {
    static final long GIOI_HAN_GIAY = 5;   // thời gian tối đa cho mỗi test

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Cach dung: java TuCham.java <TenBai>   vi du: java TuCham.java B01_TongChuSo");
            return;
        }
        String tenBai = args[0].replace(".java", "");
        Path fileNguon = Paths.get(tenBai + ".java");
        if (!Files.exists(fileNguon)) {
            System.out.println("Khong tim thay file " + fileNguon.toAbsolutePath());
            return;
        }
        String maBai = tenBai.split("_")[0];                 // "B01"
        Path thuMucTest = Paths.get("tests", maBai);
        if (!Files.isDirectory(thuMucTest)) {
            System.out.println("Khong tim thay thu muc test " + thuMucTest.toAbsolutePath());
            return;
        }

        // 1. Biên dịch bài làm vào thư mục tạm
        Path thuMucTam = Files.createTempDirectory("tucham");
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        if (javac == null) {
            System.out.println("Can cai JDK (khong phai JRE) de tu cham.");
            return;
        }
        int ketQuaBienDich = javac.run(null, null, null, "-encoding", "UTF-8",
                "-d", thuMucTam.toString(), fileNguon.toString());
        if (ketQuaBienDich != 0) {
            System.out.println("LOI BIEN DICH: sua cac loi o tren roi cham lai.");
            return;
        }

        // 2. Lấy danh sách test theo thứ tự số: 1.in, 2.in, ..., 10.in
        List<Path> dsTest = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(thuMucTest, "*.in")) {
            for (Path p : ds) dsTest.add(p);
        }
        dsTest.sort(Comparator.comparingInt(p -> Integer.parseInt(p.getFileName().toString().replace(".in", ""))));

        // 3. Chạy từng test bằng chính JVM đang chạy công cụ này
        String java = ProcessHandle.current().info().command().orElse("java");
        int soDung = 0;
        for (Path in : dsTest) {
            String ten = in.getFileName().toString().replace(".in", "");
            Path out = in.resolveSibling(ten + ".out");
            File ketQuaChay = File.createTempFile("out", ".txt");
            ProcessBuilder pb = new ProcessBuilder(java,
                    "-Duser.language=en", "-Duser.country=US",   // in số thực bằng dấu chấm trên mọi máy
                    "-cp", thuMucTam.toString(), tenBai);
            pb.redirectInput(in.toFile());
            pb.redirectOutput(ketQuaChay);
            pb.redirectError(ProcessBuilder.Redirect.INHERIT);
            Process p = pb.start();
            if (!p.waitFor(GIOI_HAN_GIAY, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                System.out.println("Test " + ten + ": QUA THOI GIAN (" + GIOI_HAN_GIAY + " giay)");
                continue;
            }
            List<String> mongDoi = chuanHoa(Files.readString(out, StandardCharsets.UTF_8));
            List<String> thucTe = chuanHoa(Files.readString(ketQuaChay.toPath(), StandardCharsets.UTF_8));
            if (mongDoi.equals(thucTe)) {
                soDung++;
                System.out.println("Test " + ten + ": DUNG");
            } else {
                System.out.println("Test " + ten + ": SAI");
                System.out.println("   Du lieu vao : " + String.join(" | ", chuanHoa(Files.readString(in))));
                inDongKhacDau(mongDoi, thucTe);
            }
        }
        System.out.println("Ket qua: " + soDung + "/" + dsTest.size() + " test dung.");
    }

    // Bỏ khoảng trắng cuối mỗi dòng và các dòng trống ở cuối, để không bắt lỗi vặt
    static List<String> chuanHoa(String s) {
        List<String> dong = new ArrayList<>();
        for (String d : s.replace("\r", "").split("\n", -1)) dong.add(d.stripTrailing());
        while (!dong.isEmpty() && dong.get(dong.size() - 1).isEmpty()) dong.remove(dong.size() - 1);
        return dong;
    }

    static void inDongKhacDau(List<String> mongDoi, List<String> thucTe) {
        int n = Math.max(mongDoi.size(), thucTe.size());
        for (int i = 0; i < n; i++) {
            String a = i < mongDoi.size() ? mongDoi.get(i) : "(khong co dong nay)";
            String b = i < thucTe.size() ? thucTe.get(i) : "(khong co dong nay)";
            if (!a.equals(b)) {
                System.out.println("   Dong " + (i + 1) + " mong doi: " + a);
                System.out.println("   Dong " + (i + 1) + " cua em  : " + b);
                return;
            }
        }
    }
}
